import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kalkulator {
    private JPanel KalkulatorPanel;
    private JTextField angka1;
    private JTextField angka2;
    private JButton add;
    private JButton kurang;
    private JButton kali;
    private JButton bagi;
    private JButton persen;
    private JTextField hasil;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Kalkulator");
        frame.setContentPane(new Kalkulator().KalkulatorPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public Kalkulator () {

        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double numb1, numb2, total;
                numb1 = Double.parseDouble(angka1.getText());
                numb2 = Double.parseDouble(angka2.getText());

                //HITUNG +
                total = numb1 + numb2;
                hasil.setText(String.valueOf(total));
            }

        });
        kurang.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double numb1, numb2, total;
                numb1 = Double.parseDouble(angka1.getText());
                numb2 = Double.parseDouble(angka2.getText());

                //HITUNG -
                total = numb1 - numb2;
                hasil.setText(String.valueOf(total));
            }
    });
        kali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double numb1, numb2, total;
                numb1 = Double.parseDouble(angka1.getText());
                numb2 = Double.parseDouble(angka2.getText());

                //HITUNG *
                total = numb1 * numb2;
                hasil.setText(String.valueOf(total));
            }
        });
        bagi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double numb1, numb2, total;
                numb1 = Double.parseDouble(angka1.getText());
                numb2 = Double.parseDouble(angka2.getText());

                //HITUNG /
                total = numb1 / numb2;
                hasil.setText(String.valueOf(total));
            }
        });
        persen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double numb1, numb2, total;
                numb1 = Double.parseDouble(angka1.getText());
                numb2 = Double.parseDouble(angka2.getText());

                //HITUNG %
                total = numb1 % numb2;
                hasil.setText(String.valueOf(total));
            }
        });
}}
