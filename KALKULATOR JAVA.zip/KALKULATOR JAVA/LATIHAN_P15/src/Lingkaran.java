import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Lingkaran {
    private JPanel VolumePanel;
    private JTextField tfPanjangTextField;
    private JTextField tfLebarTextField;
    private JTextField tfTinggiTextField;
    private JTextField tfVolumeTextField;
    private JButton hitungButton;
    private JButton resetButton;
    private JButton keluarButton;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Lingkaran");
        frame.setContentPane(new Lingkaran().VolumePanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public Lingkaran() {
        hitungButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // deklarasi variabel
                double panjang, lebar, tinggi, volume;
                //setting input
                panjang = Double.parseDouble(tfPanjangTextField.getText());
                lebar = Double.parseDouble(tfLebarTextField.getText());
                tinggi = Double.parseDouble(tfTinggiTextField.getText());
                //hitung volume
                volume = panjang*lebar*tinggi;
                //setting output volume
                tfVolumeTextField.setText(String.valueOf(volume));

            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfPanjangTextField.setText("");
                tfLebarTextField.setText("");
                tfTinggiTextField.setText("");
                tfVolumeTextField.setText("");
                tfPanjangTextField.requestFocus();
            }
        });
        keluarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        hitungButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        keluarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

            }
        }






